<script>
  window.location = "https://www.netsolitaire.com/";
</script>