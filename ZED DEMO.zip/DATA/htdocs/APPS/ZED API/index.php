<HTML>
    <BODY style="background-color:white;">
        <h2><span style="color: #000000;"><strong>ZED OS <span style="color: #ffcc00;">API</span></strong></span></h2>
        <table style="height: 76px;" border="2" width="487">
            <tbody>
            <tr>
            <td style="width: 477px; text-align: center;"><em><strong>Messages/Notifications</strong></em></td>
            </tr>
            <tr>
            <td style="width: 477px;">parent.ShowMSG("TYPE_OF_MESSAGE","TEXT OF MESSAGE")</td>
            </tr>
            <tr>
            <td style="width: 477px;">
            <h2>Types of Messages:</h2>
            <p>-MSG_ERROR <button onclick='parent.ShowMSG("MSG_ERROR","THIS IS AN ERROR");'>Try</button></p>
            <p>-MSG_ALERT <button onclick='parent.ShowMSG("MSG_ALERT","THIS IS AN ALERT");'>Try</button></p>
            <p>-MSG_INFO <button onclick='parent.ShowMSG("MSG_INFO","THIS IS AN INFO");'>Try</button></p>
            <p>-MSG_SUCESS <button onclick='parent.ShowMSG("MSG_SUCESS","THIS IS AN SUCESS");'>Try</button></p>
            </td>
            </tr>
            </tbody>
        </table>
        <p>&nbsp;</p>
    </BODY>
</HTML>
