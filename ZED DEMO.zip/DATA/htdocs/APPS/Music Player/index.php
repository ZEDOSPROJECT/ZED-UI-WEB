<script>
  window.location = "https://www.jaguarscript.com/splayer/ui-demo/";
</script>