<script>
  window.location = "https://office.live.com/start/PowerPoint.aspx";
</script>
