<script>
  window.location = "https://h5note.com/";
</script>