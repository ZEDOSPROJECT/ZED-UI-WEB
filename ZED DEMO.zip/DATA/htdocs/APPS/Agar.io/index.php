<script>
  window.location = "https://agar.io/";
</script>
