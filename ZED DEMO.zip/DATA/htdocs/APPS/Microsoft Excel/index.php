<script>
  window.location = "https://office.live.com/start/Excel.aspx";
</script>
