<script>
  window.location = "https://office.live.com/start/Word.aspx";
</script>
