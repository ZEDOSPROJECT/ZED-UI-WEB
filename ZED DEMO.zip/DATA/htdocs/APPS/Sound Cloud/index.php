<script>
  window.location = "https://soundcloud.com";
</script>
