<script>
  window.location = "https://youtube.com/";
</script>
