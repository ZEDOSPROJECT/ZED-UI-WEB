<script>
  window.location = "https://www.last.fm";
</script>