<script>
  window.location = "https://messenger.com";
</script>
