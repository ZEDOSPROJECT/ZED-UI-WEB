<script>
  window.location = "https://viliusle.github.io/miniPaint/";
</script>