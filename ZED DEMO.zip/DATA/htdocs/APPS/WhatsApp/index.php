<script>
  window.location = "https://web.whatsapp.com/";
</script>
