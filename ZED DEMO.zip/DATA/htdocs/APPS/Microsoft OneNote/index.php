<script>
  window.location = "https://www.onenote.com/";
</script>
