<script>
  window.location = "https://kiwiirc.com/nextclient/";
</script>
