A Pen created at CodePen.io. You can find this one at https://codepen.io/rishabhp/pen/aNXVbQ.

 This experiment shows how to set the active state on links in a sticky navigation bar when scrolling.

Elaborate explanation: http://codetheory.in/change-active-state-links-sticky-navigation-scroll/